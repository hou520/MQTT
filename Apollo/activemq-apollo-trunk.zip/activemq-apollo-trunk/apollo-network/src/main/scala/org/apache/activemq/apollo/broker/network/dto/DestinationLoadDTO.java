/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.activemq.apollo.broker.network.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;

/**
 * The
 *
 * @author <a href="http://hiramchirino.com">Hiram Chirino</a>
 */
@XmlRootElement(name="destination_load")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DestinationLoadDTO {

    @XmlAttribute(name="id")
    public String id;

    @XmlAttribute(name="message_count")
    public Long message_count;

    @XmlAttribute(name="message_size")
    public Long message_size;

    @XmlAttribute(name="message_count_enqueue_counter")
    public Long message_count_enqueue_counter;

    @XmlAttribute(name="message_size_enqueue_counter")
    public Long message_size_enqueue_counter;

    @XmlAttribute(name="message_count_dequeue_counter")
    public Long message_count_dequeue_counter;

    @XmlAttribute(name="message_size_dequeue_counter")
    public Long message_size_dequeue_counter;

    @XmlElement(name="consumer")
    public ArrayList<ConsumerLoadDTO> consumers = new ArrayList<ConsumerLoadDTO>();

}
