# RabbitMQ 中文文档 已迁移至新站点

此处不再提供服务，请异步 [rabbitmq.mr-ping.com][1] 进行浏览。

[1]: http://rabbitmq.mr-ping.com
