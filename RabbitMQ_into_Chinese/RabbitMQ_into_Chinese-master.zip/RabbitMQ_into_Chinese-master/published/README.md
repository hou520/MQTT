# RabbitMQ 中文文档

![CC BY-SA](https://licensebuttons.net/l/by-sa/3.0/88x31.png)

欢迎大家在 [GitHub项目](https://github.com/mr-ping/RabbitMQ_into_Chinese) 中参与文档翻译。
