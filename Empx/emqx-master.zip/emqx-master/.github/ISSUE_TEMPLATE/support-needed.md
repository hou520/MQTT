---
name: Support Needed
about: Asking a question about usages, docs or anything you're insterested in
title: ''
labels: Support
assignees: tigercl

---

**Please describe your problem in detail, if necessary, you can upload the log file through the attachment**:
